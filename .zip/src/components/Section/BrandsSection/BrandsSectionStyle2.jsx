import React from 'react';
import BrandsCarousel from '../../Slider/BrandsCarousel';

export default function BrandsSectionStyle2({ data }) {
  return <BrandsCarousel data={data} />;
}

import React from 'react';
import FeatureCarousel from '../../Slider/FeatureCarousel';

export default function FeaturesSectionStyle4({ sectionTitle, data }) {
  return <FeatureCarousel sectionTitle={sectionTitle} data={data} />;
}

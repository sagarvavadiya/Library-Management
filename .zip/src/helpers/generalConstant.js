export const authToken = localStorage.getItem("accessToken") ?? ""; //`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY1ODUxNzliYmNhODgwOGUxZTBkYTk5OSIsInJvbGUiOiJBRE1JTiIsImlhdCI6MTcxMDA1Njk3OSwiZXhwIjoxNzEyNjQ4OTc5fQ.0wEKa34cT66nQSIonTPollza9ftZWnq3IdcSh14IDSM`;
export const baseUrl = `https://lms-api-e6xd.onrender.com/api`;
export const USER_ID = `test`;

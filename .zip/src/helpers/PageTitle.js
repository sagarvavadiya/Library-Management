export const pageTitle = title => {
  return (document.title =
    title + ' -  ProHealth - Medical and Healthcare React App');
};
